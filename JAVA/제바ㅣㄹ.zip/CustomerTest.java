package org.javaro.lecture;

import java.io.IOException;

public class CustomerTest {
	public static void main(String[] args) throws IOException {
		CustomerManager cm = new CustomerManager();
		cm.start(); //����
	}
}